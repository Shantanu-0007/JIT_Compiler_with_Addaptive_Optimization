#!/usr/bin/env sh
set -e
node ./tablegen-x86.js $@
