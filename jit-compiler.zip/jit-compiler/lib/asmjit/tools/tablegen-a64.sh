#!/bin/sh

node ./tablegen-a64.js
